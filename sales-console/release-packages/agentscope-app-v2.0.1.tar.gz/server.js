const APP_VERSION = '2.0.1';

export { APP_VERSION };

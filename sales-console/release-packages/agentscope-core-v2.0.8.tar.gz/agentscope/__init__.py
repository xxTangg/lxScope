"""AgentScope core platform release marker."""

__version__ = "2.0.8"
